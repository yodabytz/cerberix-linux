# krellix

A themeable Qt 6 desktop system monitor in the spirit of GKrellM.

A skinny vertical panel of stacked "krell" monitors — CPU, memory, disk, net, sensors,
and more — driven by a clean-sheet native theme format that any user can author.

> **Status: 0.1.0-beta.** Host, CPU (per-core krell + chart), Memory/Swap, and Clock
> monitors render against a hot-reloadable theme. Disk, Net, FS, Sensors, Battery,
> and the optional `krellixd` remote daemon are still to come. Expect breakages
> while the API stabilizes.

<img src="https://raw.githubusercontent.com/yodabytz/krellix/refs/heads/main/krellix-display2.png" width="400">

## Build

Requires Qt 6.2+ and a C++17 compiler.

```bash
sudo apt install qt6-base-dev cmake g++   # Debian/Ubuntu
cmake -S . -B build
cmake --build build -j
./build/bin/krellix
```

Run with a specific theme:

```bash
./build/bin/krellix --theme default
```

## Themes

Themes live in:

- `~/.config/krellix/themes/<name>/` (user, takes precedence)
- `/usr/share/krellix/themes/<name>/` (system)

A theme is a directory containing `theme.json` plus any PNG sprites it references.
See [`docs/theme-spec.md`](docs/theme-spec.md) for the full format.

While krellix is running, edits to `theme.json` are picked up automatically — the
panel repaints on save, so theme authors can iterate without restarting the app.

## License

GPL-3.0-or-later. See `COPYING` (TODO).
