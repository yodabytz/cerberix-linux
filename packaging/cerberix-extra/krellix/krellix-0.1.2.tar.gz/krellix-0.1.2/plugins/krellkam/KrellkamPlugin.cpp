#include "KrellkamPlugin.h"

#include "theme/Theme.h"
#include "widgets/Panel.h"

#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QDialog>
#include <QLabel>
#include <QLayout>
#include <QMouseEvent>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QPainter>
#include <QProcess>
#include <QPushButton>
#include <QRegularExpression>
#include <QSettings>
#include <QStandardPaths>
#include <QTimer>
#include <QUrlQuery>
#include <QVBoxLayout>

#include <algorithm>

namespace {

constexpr int kMaxSources = 5;
constexpr qint64 kMaxImageBytes = 10LL * 1024LL * 1024LL;
constexpr qint64 kMaxImagePixels = 4096LL * 4096LL;
constexpr int kFetchTimeoutMs = 15000;
constexpr int kYoutubeFrameMaxWidth = 1280;

QList<KrellkamSource> configuredSources()
{
    QSettings s;
    QList<KrellkamSource> out;

    const QStringList packed = s.value(QStringLiteral("plugins/krellkam/sources"))
                                   .toString()
                                   .split(QRegularExpression(QStringLiteral("[\\n;,]")),
                                          Qt::SkipEmptyParts);
    for (const QString &entry : packed) {
        const QString source = entry.trimmed();
        if (!source.isEmpty() && out.size() < kMaxSources)
            out.append(KrellkamSource{QString(), QStringLiteral("auto"), source});
    }

    for (int i = 1; i <= kMaxSources && out.size() < kMaxSources; ++i) {
        const QString source =
            s.value(QStringLiteral("plugins/krellkam/source%1").arg(i))
                .toString()
                .trimmed();
        if (source.isEmpty()) continue;
        bool duplicate = false;
        for (const KrellkamSource &existing : out) {
            if (existing.source == source) {
                duplicate = true;
                break;
            }
        }
        if (duplicate) continue;
        const QString type =
            s.value(QStringLiteral("plugins/krellkam/type%1").arg(i),
                    QStringLiteral("auto")).toString().trimmed().toLower();
        const QString title =
            s.value(QStringLiteral("plugins/krellkam/title%1").arg(i))
                .toString()
                .trimmed();
        out.append(KrellkamSource{title,
                                  type.isEmpty() ? QStringLiteral("auto") : type,
                                  source});
    }

    return out;
}

bool isRemote(const QString &source)
{
    const QUrl url(source);
    return url.isValid()
        && (url.scheme() == QStringLiteral("http")
            || url.scheme() == QStringLiteral("https"));
}

bool isYoutubeUrl(const QString &source)
{
    const QUrl url(source);
    const QString host = url.host().toLower();
    return host.contains(QStringLiteral("youtube.com"))
        || host.contains(QStringLiteral("youtu.be"));
}

bool executableExists(const QString &program)
{
    return !QStandardPaths::findExecutable(program).isEmpty();
}

int indexOfBytes(const QByteArray &bytes, const QByteArray &needle, int from = 0)
{
    return bytes.indexOf(needle, from);
}

QStringList splitOptionalCommandArgs(const QString &value)
{
    if (value.trimmed().isEmpty())
        return {};
    return QProcess::splitCommand(value);
}

QString expandUserPath(QString path)
{
    path = path.trimmed();
    if ((path.startsWith(QLatin1Char('"')) && path.endsWith(QLatin1Char('"')))
        || (path.startsWith(QLatin1Char('\'')) && path.endsWith(QLatin1Char('\'')))) {
        path = path.mid(1, path.size() - 2).trimmed();
    }
    if (path.startsWith(QStringLiteral("file://"))) {
        const QUrl url(path);
        if (url.isLocalFile())
            path = url.toLocalFile();
    }
    if (path == QLatin1String("~"))
        return QDir::homePath();
    if (path.startsWith(QStringLiteral("~/")))
        return QDir::homePath() + path.mid(1);
    if (path == QLatin1String("$HOME"))
        return QDir::homePath();
    if (path.startsWith(QStringLiteral("$HOME/")))
        return QDir::homePath() + path.mid(5);
    if (path == QLatin1String("${HOME}"))
        return QDir::homePath();
    if (path.startsWith(QStringLiteral("${HOME}/")))
        return QDir::homePath() + path.mid(7);
    return path;
}

QString cookieFileProblem(const QString &path)
{
    if (path.isEmpty())
        return {};
    const QFileInfo info(path);
    if (!info.exists())
        return QStringLiteral("cookie file not found: %1").arg(path);
    if (!info.isFile())
        return QStringLiteral("cookie path is not a file: %1").arg(path);
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text))
        return QStringLiteral("cookie file not readable: %1").arg(path);
    const QByteArray head = f.read(4096);
    if (!head.contains("youtube") && !head.contains("google"))
        return QStringLiteral("cookie file has no YouTube/Google cookies");
    return {};
}

QString shortYoutubeError(QString err)
{
    err = err.trimmed();
    if (err.contains(QStringLiteral("Sign in to confirm"), Qt::CaseInsensitive)
        || err.contains(QStringLiteral("LOGIN_REQUIRED"), Qt::CaseInsensitive)) {
        QSettings s;
        const QString cookiesFile = expandUserPath(
            s.value(QStringLiteral("plugins/krellkam/youtube_cookies_file")).toString());
        const QString cookiesFromBrowser =
            s.value(QStringLiteral("plugins/krellkam/youtube_cookies_from_browser")).toString().trimmed();
        if (!cookiesFile.isEmpty() || !cookiesFromBrowser.isEmpty())
            return QStringLiteral("youtube rejected configured cookies; refresh Krellkam cookies");
        return QStringLiteral("youtube verification required; set cookies in Krellkam settings");
    }
    if (err.contains(QStringLiteral("could not open cookies file"), Qt::CaseInsensitive)
        || err.contains(QStringLiteral("cookies file must be"), Qt::CaseInsensitive)
        || err.contains(QStringLiteral("cookie file"), Qt::CaseInsensitive)) {
        return err.left(160);
    }
    if (err.contains(QStringLiteral("cookies-from-browser"), Qt::CaseInsensitive)
        || err.contains(QStringLiteral("--cookies"), Qt::CaseInsensitive)) {
        return QStringLiteral("youtube wants browser cookies; set Krellkam cookies");
    }
    return err.isEmpty() ? QStringLiteral("yt-dlp failed") : err.left(160);
}

QStringList youtubeResolverArgs(const QString &source)
{
    QSettings s;
    QStringList args;

    const QString cookiesFile = expandUserPath(
        s.value(QStringLiteral("plugins/krellkam/youtube_cookies_file")).toString());
    QString cookiesFromBrowser =
        s.value(QStringLiteral("plugins/krellkam/youtube_cookies_from_browser"),
                QStringLiteral("auto")).toString().trimmed();
    if (!cookiesFile.isEmpty()) {
        const QFileInfo cookiesInfo(cookiesFile);
        args << QStringLiteral("--cookies")
             << (cookiesInfo.exists() ? cookiesInfo.absoluteFilePath() : cookiesFile);
    } else {
        if (cookiesFromBrowser == QStringLiteral("auto")) {
            const QString home = QDir::homePath();
            if (QDir(home + QStringLiteral("/.mozilla/firefox")).exists())
                cookiesFromBrowser = QStringLiteral("firefox");
            else if (QDir(home + QStringLiteral("/.config/chromium")).exists())
                cookiesFromBrowser = QStringLiteral("chromium");
            else if (QDir(home + QStringLiteral("/.config/google-chrome")).exists())
                cookiesFromBrowser = QStringLiteral("chrome");
            else if (QDir(home + QStringLiteral("/.config/BraveSoftware/Brave-Browser")).exists())
                cookiesFromBrowser = QStringLiteral("brave");
            else
                cookiesFromBrowser.clear();
        }
    }
    if (!cookiesFile.isEmpty()) {
        // Already added above.
    } else if (!cookiesFromBrowser.isEmpty()) {
        args << QStringLiteral("--cookies-from-browser") << cookiesFromBrowser;
    }

    const QString extractorArgs =
        s.value(QStringLiteral("plugins/krellkam/youtube_extractor_args"),
                QStringLiteral("youtube:player_client=tv,web_safari,mweb,default"))
            .toString()
            .trimmed();
    if (!extractorArgs.isEmpty())
        args << QStringLiteral("--extractor-args") << extractorArgs;

    args << splitOptionalCommandArgs(
        s.value(QStringLiteral("plugins/krellkam/youtube_yt_dlp_args")).toString());
    args << QStringLiteral("--no-playlist")
         << QStringLiteral("-f")
         << QStringLiteral("best[height<=1080]/best[height<=720]/best[height<=480]/best")
         << QStringLiteral("-g")
         << source;

    return args;
}

class KrellkamImageViewer final : public QLabel
{
public:
    explicit KrellkamImageViewer(QWidget *parent = nullptr)
        : QLabel(parent)
    {
        setAlignment(Qt::AlignCenter);
        setMinimumSize(180, 120);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        setStyleSheet(QStringLiteral("QLabel { background: #050607; }"));
    }

    void setImage(const QImage &image)
    {
        m_image = image;
        updatePixmap();
    }

    QSize sizeHint() const override
    {
        if (m_image.isNull())
            return QLabel::sizeHint();
        return m_image.size().scaled(QSize(760, 520), Qt::KeepAspectRatio);
    }

protected:
    void resizeEvent(QResizeEvent *event) override
    {
        QLabel::resizeEvent(event);
        updatePixmap();
    }

private:
    void updatePixmap()
    {
        if (m_image.isNull() || width() <= 0 || height() <= 0)
            return;

        const QSize target = m_image.size().scaled(contentsRect().size(),
                                                   Qt::KeepAspectRatio);
        QLabel::setPixmap(QPixmap::fromImage(m_image).scaled(target,
                                                             Qt::KeepAspectRatio,
                                                             Qt::SmoothTransformation));
    }

    QImage m_image;
};

} // namespace

KrellkamField::KrellkamField(Theme *theme, QWidget *parent)
    : QWidget(parent)
    , m_theme(theme)
{
    Q_ASSERT(m_theme);
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    setAttribute(Qt::WA_OpaquePaintEvent, true);
    setCursor(Qt::PointingHandCursor);
    connect(m_theme, &Theme::themeChanged, this, &KrellkamField::onThemeChanged);
}

KrellkamField::~KrellkamField()
{
    stopProcesses();
}

void KrellkamField::stopProcesses()
{
    const QList<QProcess *> processes = findChildren<QProcess *>();
    for (QProcess *process : processes) {
        if (!process) continue;
        process->disconnect(this);
        if (process->state() == QProcess::NotRunning)
            continue;
        process->terminate();
        if (!process->waitForFinished(500)) {
            process->kill();
            process->waitForFinished(500);
        }
    }
}

void KrellkamField::setSources(const QList<KrellkamSource> &sources)
{
    if (sources == m_sources && !m_slots.isEmpty()) {
        requestRelayout();
        return;
    }
    m_sources = sources;
    m_slots.clear();
    for (const KrellkamSource &source : sources.mid(0, kMaxSources)) {
        Slot slot;
        slot.title = source.title;
        slot.type = source.type;
        slot.source = source.source;
        slot.status = QStringLiteral("loading");
        m_slots.append(slot);
    }
    if (m_slots.isEmpty()) {
        Slot slot;
        slot.status = QStringLiteral("add a camera in Settings > Plugins");
        m_slots.append(slot);
    }
    requestRelayout();
}

void KrellkamField::refresh()
{
    requestRelayout();
    for (int i = 0; i < m_slots.size(); ++i)
        requestSource(i);
}

QSize KrellkamField::sizeHint() const
{
    const int per = qBound(24,
        QSettings().value(QStringLiteral("plugins/krellkam/field_height"),
                          m_theme->metric(QStringLiteral("chart_height"), 48)).toInt(),
        240);
    const int spacing = m_theme->metric(QStringLiteral("panel_spacing"), 2);
    return QSize(0, m_slots.size() * per + qMax(0, m_slots.size() - 1) * spacing);
}

QSize KrellkamField::minimumSizeHint() const
{
    return QSize(0, qMax(20, m_slots.size() * 20));
}

void KrellkamField::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::SmoothPixmapTransform, true);
    p.setRenderHint(QPainter::TextAntialiasing, true);

    const int count = qMax(1, m_slots.size());
    const int spacing = m_theme->metric(QStringLiteral("panel_spacing"), 2);
    const int h = (height() - spacing * (count - 1)) / count;
    int y = 0;

    for (int i = 0; i < count; ++i) {
        const QRect r(0, y, width(), qMax(1, i == count - 1 ? height() - y : h));
        paintChartBackground(p, r);

        const Slot &slot = m_slots.at(i);
        if (!slot.image.isNull()) {
            p.drawImage(r, slot.image);
        } else {
            const Theme::TextStyle ts = m_theme->textStyle(
                QStringLiteral("chart_overlay"),
                QStringLiteral("text_secondary"));
            const QRect textRect = r.adjusted(4, 1, -4, -1);
            if (ts.shadow.present) {
                p.setPen(ts.shadow.color);
                p.drawText(textRect.translated(ts.shadow.offsetX, ts.shadow.offsetY),
                           Qt::AlignCenter | Qt::TextWordWrap, slot.status);
            }
            p.setPen(ts.color.isValid() ? ts.color
                                        : m_theme->color(QStringLiteral("text_secondary")));
            p.drawText(textRect, Qt::AlignCenter | Qt::TextWordWrap, slot.status);
        }
        if (!slot.title.isEmpty()) {
            QFont f = m_theme->font(QStringLiteral("label"));
            p.setFont(f);
            const QFontMetrics fm(f);
            const int titleH = qBound(10, fm.height() + 2, qMax(10, r.height() / 3));
            const QRect titleRect = QRect(r.left(), r.top(), r.width(), titleH);
            QColor bg = m_theme->color(QStringLiteral("chart_bg"), QColor(0, 0, 0));
            bg.setAlpha(185);
            p.fillRect(titleRect, bg);
            const Theme::TextStyle ts = m_theme->textStyle(
                QStringLiteral("chart_overlay"),
                QStringLiteral("text_primary"));
            const QRect textRect = titleRect.adjusted(3, 0, -3, 0);
            if (ts.shadow.present) {
                p.setPen(ts.shadow.color);
                p.drawText(textRect.translated(ts.shadow.offsetX, ts.shadow.offsetY),
                           Qt::AlignVCenter | Qt::AlignLeft,
                           fm.elidedText(slot.title, Qt::ElideRight, textRect.width()));
            }
            p.setPen(ts.color.isValid() ? ts.color
                                        : m_theme->color(QStringLiteral("text_primary")));
            p.drawText(textRect, Qt::AlignVCenter | Qt::AlignLeft,
                       fm.elidedText(slot.title, Qt::ElideRight, textRect.width()));
        }

        y += r.height() + spacing;
    }
}

void KrellkamField::onThemeChanged()
{
    requestRelayout();
}

void KrellkamField::requestRelayout()
{
    updateGeometry();
    update();
    if (QWidget *p = parentWidget()) {
        if (QLayout *layout = p->layout())
            layout->invalidate();
        p->updateGeometry();
        p->update();
    }
    if (QWidget *w = window()) {
        if (QLayout *layout = w->layout())
            layout->activate();
        w->updateGeometry();
    }
    update();
}

void KrellkamField::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        const int index = slotAt(event->pos());
        if (index >= 0 && index < m_slots.size() && !m_slots.at(index).image.isNull()) {
            openViewer(index);
            event->accept();
            return;
        }
    }
    QWidget::mousePressEvent(event);
}

void KrellkamField::requestSource(int index)
{
    if (index < 0 || index >= m_slots.size()) return;
    if (m_slots.at(index).fetching) return;
    QString type = m_slots.at(index).type.trimmed().toLower();
    const QString source = m_slots.at(index).source;
    if (source.isEmpty()) return;

    if (type.isEmpty()) type = QStringLiteral("auto");
    if (type == QStringLiteral("command")) {
        if (!QSettings().value(QStringLiteral("plugins/krellkam/allow_command_sources"),
                               false).toBool()) {
            setSlotError(index, QStringLiteral("command source disabled"));
            return;
        }
        requestCommandSource(index, source);
        return;
    }
    if (type == QStringLiteral("mjpeg")) {
        requestMjpegSource(index, source);
        return;
    }
    if (type == QStringLiteral("youtube") || (type == QStringLiteral("auto") && isYoutubeUrl(source))) {
        requestYoutubeSource(index, source);
        return;
    }
    requestImageSource(index, source);
}

void KrellkamField::requestImageSource(int index, const QString &source)
{
    if (!isRemote(source)) {
        QFile f(source);
        if (!f.open(QIODevice::ReadOnly)) {
            setSlotError(index, QStringLiteral("cannot read image"));
            return;
        }
        if (f.size() > kMaxImageBytes) {
            setSlotError(index, QStringLiteral("image too large"));
            return;
        }
        setSlotImage(index, f.readAll());
        return;
    }

    QUrl url(source);
    QUrlQuery query(url);
    query.removeQueryItem(QStringLiteral("_krellkam"));
    query.addQueryItem(QStringLiteral("_krellkam"),
                       QString::number(QDateTime::currentMSecsSinceEpoch()));
    url.setQuery(query);

    QNetworkRequest req{url};
    req.setAttribute(QNetworkRequest::CacheLoadControlAttribute,
                     QNetworkRequest::AlwaysNetwork);
    req.setRawHeader("Cache-Control", "no-cache, no-store, max-age=0");
    req.setRawHeader("Pragma", "no-cache");
    req.setRawHeader("User-Agent", "krellix-krellkam/0.1");
    req.setMaximumRedirectsAllowed(3);
    req.setTransferTimeout(kFetchTimeoutMs);
    QNetworkReply *reply = m_net.get(req);
    auto *payload = new QByteArray;
    connect(reply, &QObject::destroyed, this, [payload]() { delete payload; });
    connect(reply, &QNetworkReply::readyRead, this, [this, reply, payload, index]() {
        payload->append(reply->readAll());
        if (payload->size() > kMaxImageBytes) {
            setSlotError(index, QStringLiteral("image too large"));
            reply->abort();
        }
    });
    connect(reply, &QNetworkReply::finished, this, [this, reply, payload, index]() {
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            if (reply->error() == QNetworkReply::OperationCanceledError)
                return;
            setSlotError(index, reply->errorString());
            return;
        }
        payload->append(reply->readAll());
        if (payload->size() > kMaxImageBytes) {
            setSlotError(index, QStringLiteral("image too large"));
            return;
        }
        setSlotImage(index, *payload);
    });
}

void KrellkamField::requestMjpegSource(int index, const QString &source)
{
    QNetworkRequest req{QUrl(source)};
    req.setAttribute(QNetworkRequest::CacheLoadControlAttribute,
                     QNetworkRequest::AlwaysNetwork);
    req.setRawHeader("User-Agent", "krellix-krellkam/0.1");
    req.setMaximumRedirectsAllowed(3);
    req.setTransferTimeout(kFetchTimeoutMs);

    QNetworkReply *reply = m_net.get(req);
    auto *buffer = new QByteArray;
    connect(reply, &QObject::destroyed, this, [buffer]() { delete buffer; });
    connect(reply, &QNetworkReply::readyRead, this, [this, reply, buffer, index]() {
        buffer->append(reply->readAll());
        if (buffer->size() > 4 * 1024 * 1024)
            buffer->remove(0, buffer->size() - 1024 * 1024);
        if (tryExtractMjpegFrame(index, *buffer))
            reply->abort();
    });
    connect(reply, &QNetworkReply::finished, this, [this, reply, buffer, index]() {
        reply->deleteLater();
        if (reply->error() == QNetworkReply::OperationCanceledError)
            return;
        if (reply->error() != QNetworkReply::NoError) {
            setSlotError(index, reply->errorString());
            return;
        }
        (void) tryExtractMjpegFrame(index, *buffer);
    });
}

void KrellkamField::requestYoutubeSource(int index, const QString &source)
{
    if (index < 0 || index >= m_slots.size()) return;
    m_slots[index].fetching = true;
    requestYoutubeFrame(source, [this, index](const QByteArray &image, const QString &error) {
        if (index >= 0 && index < m_slots.size())
            m_slots[index].fetching = false;
        if (!error.isEmpty()) {
            setSlotError(index, error);
            return;
        }
        setSlotImage(index, image);
    });
}

void KrellkamField::requestYoutubeFrame(const QString &source,
                                        std::function<void(const QByteArray &, const QString &)> callback)
{
    if (!executableExists(QStringLiteral("yt-dlp"))) {
        callback({}, QStringLiteral("yt-dlp not installed"));
        return;
    }
    if (!executableExists(QStringLiteral("ffmpeg"))) {
        callback({}, QStringLiteral("ffmpeg not installed"));
        return;
    }

    const QString cookiesFile = expandUserPath(
        QSettings().value(QStringLiteral("plugins/krellkam/youtube_cookies_file")).toString());
    const QString cookieProblem = cookieFileProblem(cookiesFile);
    if (!cookieProblem.isEmpty()) {
        callback({}, cookieProblem);
        return;
    }

    const YoutubeStream cached = m_youtubeStreams.value(source);
    if (!cached.url.isEmpty()
        && cached.resolvedAt.secsTo(QDateTime::currentDateTimeUtc()) < 600) {
        requestYoutubeFrameFromStream(cached.url, callback);
        return;
    }

    auto *resolver = new QProcess(this);
    resolver->setProgram(QStringLiteral("yt-dlp"));
    resolver->setArguments(youtubeResolverArgs(source));
    resolver->setProcessChannelMode(QProcess::SeparateChannels);
    connect(resolver, &QProcess::errorOccurred, this,
            [resolver, callback](QProcess::ProcessError) {
                // When OUR watchdog kills the process for timeout, QProcess
                // transitions to Crashed and reports errorString() = "Process
                // crashed". That's misleading on the panel — the slot just
                // didn't return in time. Distinguish via a property set by
                // the timer; show "stream timeout" so users can tell a slow
                // network from a genuine crash.
                const bool killedByUs = resolver->property(
                    "krellkam_killed_by_timeout").toBool();
                const QString err = resolver->errorString();
                resolver->disconnect();
                resolver->deleteLater();
                if (killedByUs) {
                    callback({}, QStringLiteral("stream timeout"));
                    return;
                }
                callback({}, err.isEmpty() ? QStringLiteral("yt-dlp failed") : err.left(160));
            });
    connect(resolver,
            QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, [this, resolver, source, callback](int exitCode, QProcess::ExitStatus status) {
                const QString streamUrl = QString::fromLocal8Bit(resolver->readAllStandardOutput())
                                              .split(QLatin1Char('\n'), Qt::SkipEmptyParts)
                                              .value(0)
                                              .trimmed();
                const QString err = QString::fromLocal8Bit(resolver->readAllStandardError()).trimmed();
                resolver->deleteLater();
                if (status != QProcess::NormalExit || exitCode != 0 || streamUrl.isEmpty()) {
                    callback({}, shortYoutubeError(err));
                    return;
                }

                m_youtubeStreams.insert(source, YoutubeStream{streamUrl, QDateTime::currentDateTimeUtc()});
                requestYoutubeFrameFromStream(streamUrl, callback);
            });
    // 30s — YouTube stream resolution can be slow on a cold VM (DNS,
    // first-time cert handshake, yt-dlp signature extraction). The
    // previous 12s window often tripped right after a VM boot before
    // the network was fully warm. Tag the process so the error handler
    // can render a friendly message instead of "Process crashed".
    QTimer::singleShot(30000, resolver, [resolver]() {
        if (resolver->state() != QProcess::NotRunning) {
            resolver->setProperty("krellkam_killed_by_timeout", true);
            resolver->kill();
        }
    });
    resolver->start();
}

void KrellkamField::requestYoutubeFrameFromStream(
    const QString &streamUrl,
    std::function<void(const QByteArray &, const QString &)> callback)
{
    auto *ffmpeg = new QProcess(this);
    ffmpeg->setProgram(QStringLiteral("ffmpeg"));
    ffmpeg->setArguments({QStringLiteral("-hide_banner"),
                          QStringLiteral("-nostdin"),
                          QStringLiteral("-loglevel"), QStringLiteral("error"),
                          QStringLiteral("-threads"), QStringLiteral("1"),
                          QStringLiteral("-i"), streamUrl,
                          QStringLiteral("-frames:v"), QStringLiteral("1"),
                          QStringLiteral("-vf"),
                          QStringLiteral("scale='min(%1,iw)':-2").arg(kYoutubeFrameMaxWidth),
                          QStringLiteral("-f"), QStringLiteral("image2pipe"),
                          QStringLiteral("-vcodec"), QStringLiteral("mjpeg"),
                          QStringLiteral("-")});
    ffmpeg->setProcessChannelMode(QProcess::SeparateChannels);
    connect(ffmpeg, &QProcess::errorOccurred, this,
            [ffmpeg, callback](QProcess::ProcessError) {
                const bool killedByUs = ffmpeg->property(
                    "krellkam_killed_by_timeout").toBool();
                const QString err = ffmpeg->errorString();
                ffmpeg->disconnect();
                ffmpeg->deleteLater();
                if (killedByUs) {
                    callback({}, QStringLiteral("stream timeout"));
                    return;
                }
                callback({}, err.isEmpty() ? QStringLiteral("ffmpeg failed") : err.left(160));
            });
    connect(ffmpeg,
            QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, [ffmpeg, callback](int code, QProcess::ExitStatus ffStatus) {
                const QByteArray image = ffmpeg->readAllStandardOutput();
                const QString errText = QString::fromLocal8Bit(ffmpeg->readAllStandardError()).trimmed();
                ffmpeg->deleteLater();
                if (ffStatus != QProcess::NormalExit || code != 0 || image.isEmpty()) {
                    callback({}, errText.isEmpty()
                        ? QStringLiteral("ffmpeg failed")
                        : errText.left(160));
                    return;
                }
                callback(image, QString());
            });
    QTimer::singleShot(25000, ffmpeg, [ffmpeg]() {
        if (ffmpeg->state() != QProcess::NotRunning) {
            ffmpeg->setProperty("krellkam_killed_by_timeout", true);
            ffmpeg->kill();
        }
    });
    ffmpeg->start();
}

void KrellkamField::requestCommandSource(int index, const QString &source)
{
    auto *proc = new QProcess(this);
    proc->setProgram(QStringLiteral("/bin/sh"));
    proc->setArguments({QStringLiteral("-c"), source});
    connect(proc, &QProcess::errorOccurred, this,
            [this, proc, index](QProcess::ProcessError) {
                const bool killedByUs = proc->property(
                    "krellkam_killed_by_timeout").toBool();
                const QString err = proc->errorString();
                proc->disconnect();
                proc->deleteLater();
                if (killedByUs) {
                    setSlotError(index, QStringLiteral("command timeout"));
                    return;
                }
                setSlotError(index, err.isEmpty()
                    ? QStringLiteral("command failed")
                    : err.left(160));
            });
    connect(proc, &QProcess::finished, this,
            [this, proc, index](int exitCode, QProcess::ExitStatus status) {
                proc->deleteLater();
                if (status != QProcess::NormalExit || exitCode != 0) {
                    const QString err = QString::fromLocal8Bit(proc->readAllStandardError())
                                            .trimmed();
                    setSlotError(index, err.isEmpty()
                        ? QStringLiteral("command failed")
                        : err.left(160));
                    return;
                }
                setSlotImage(index, proc->readAllStandardOutput());
            });
    QTimer::singleShot(20000, proc, [proc]() {
        if (proc->state() != QProcess::NotRunning) {
            proc->setProperty("krellkam_killed_by_timeout", true);
            proc->kill();
        }
    });
    proc->start();
}

void KrellkamField::setSlotImage(int index, const QByteArray &bytes)
{
    if (index < 0 || index >= m_slots.size()) return;
    if (bytes.size() > kMaxImageBytes) {
        setSlotError(index, QStringLiteral("image too large"));
        return;
    }
    QImage image;
    if (!image.loadFromData(bytes)) {
        setSlotError(index, QStringLiteral("bad image"));
        return;
    }
    if (static_cast<qint64>(image.width()) * image.height() > kMaxImagePixels) {
        setSlotError(index, QStringLiteral("image too large"));
        return;
    }
    m_slots[index].image = image;
    m_slots[index].status.clear();
    updateViewers(index);
    update();
}

void KrellkamField::updateViewers(int index)
{
    if (index < 0 || index >= m_slots.size() || m_slots.at(index).image.isNull())
        return;

    QList<QPointer<QLabel>> live;
    for (const QPointer<QLabel> &viewer : m_viewers.value(index)) {
        if (!viewer)
            continue;
        live.append(viewer);
        if (auto *imageViewer = dynamic_cast<KrellkamImageViewer *>(viewer.data()))
            imageViewer->setImage(m_slots.at(index).image);
    }

    if (live.isEmpty())
        m_viewers.remove(index);
    else
        m_viewers.insert(index, live);
}

bool KrellkamField::tryExtractMjpegFrame(int index, QByteArray &buffer)
{
    int start = indexOfBytes(buffer, QByteArray::fromHex("ffd8"));
    if (start < 0) return false;

    int end = indexOfBytes(buffer, QByteArray::fromHex("ffd9"), start + 2);
    if (end < 0) {
        if (start > 0) buffer.remove(0, start);
        return false;
    }

    end += 2;
    const QByteArray frame = buffer.mid(start, end - start);
    buffer.remove(0, end);
    setSlotImage(index, frame);
    return true;
}

void KrellkamField::setSlotError(int index, const QString &status)
{
    if (index < 0 || index >= m_slots.size()) return;
    m_slots[index].status = status;
    update();
}

void KrellkamField::paintChartBackground(QPainter &p, const QRect &rect) const
{
    const QPixmap bgPix = m_theme->pixmap(QStringLiteral("chart_bg"));
    if (!bgPix.isNull() && rect.height() > 0) {
        const QString mode = m_theme->imageMode(QStringLiteral("chart_bg"),
                                                QStringLiteral("tile"));
        if (mode == QStringLiteral("stretch")) {
            p.drawPixmap(rect, bgPix);
        } else {
            const QPixmap scaled = (bgPix.height() == rect.height())
                ? bgPix
                : bgPix.scaledToHeight(rect.height(), Qt::SmoothTransformation);
            p.drawTiledPixmap(rect, scaled);
        }
    } else {
        p.fillRect(rect, m_theme->brush(QStringLiteral("chart_bg"), rect,
                                        m_theme->color(QStringLiteral("chart_bg"))));
    }

    p.setPen(m_theme->color(QStringLiteral("chart_grid")));
    p.drawRect(rect.adjusted(0, 0, -1, -1));
}

int KrellkamField::slotAt(const QPoint &pos) const
{
    const int count = qMax(1, m_slots.size());
    const int spacing = m_theme->metric(QStringLiteral("panel_spacing"), 2);
    const int h = (height() - spacing * (count - 1)) / count;
    int y = 0;
    for (int i = 0; i < count; ++i) {
        const QRect r(0, y, width(), qMax(1, i == count - 1 ? height() - y : h));
        if (r.contains(pos)) return i;
        y += r.height() + spacing;
    }
    return -1;
}

void KrellkamField::openViewer(int index)
{
    if (index < 0 || index >= m_slots.size()) return;
    const Slot &slot = m_slots.at(index);
    if (slot.image.isNull()) return;

    auto *dialog = new QDialog(window());
    dialog->setAttribute(Qt::WA_DeleteOnClose, true);
    dialog->setWindowTitle(slot.source.isEmpty()
        ? QStringLiteral("Krellkam")
        : QStringLiteral("Krellkam - %1").arg(slot.source));
    dialog->setWindowFlag(Qt::Tool, true);

    auto *layout = new QVBoxLayout(dialog);
    layout->setContentsMargins(8, 8, 8, 8);
    layout->setSpacing(6);

    auto *image = new KrellkamImageViewer(dialog);

    const QSize target = slot.image.size().scaled(QSize(760, 520), Qt::KeepAspectRatio);
    image->setMinimumSize(slot.image.size().scaled(QSize(240, 180), Qt::KeepAspectRatio));
    image->setImage(slot.image);
    layout->addWidget(image, 1);

    m_viewers[index].append(QPointer<QLabel>(image));
    connect(dialog, &QObject::destroyed, this, [this, index]() { updateViewers(index); });

    auto *close = new QPushButton(QStringLiteral("Close"), dialog);
    connect(close, &QPushButton::clicked, dialog, &QDialog::close);
    layout->addWidget(close, 0, Qt::AlignRight);

    dialog->resize(target.width() + 16, target.height() + close->sizeHint().height() + 30);
    dialog->show();
}

KrellkamMonitor::KrellkamMonitor(Theme *theme, QObject *parent)
    : MonitorBase(theme, parent)
{
}

KrellkamMonitor::~KrellkamMonitor() = default;

QString KrellkamMonitor::id() const
{
    return QStringLiteral("krellkam");
}

QString KrellkamMonitor::displayName() const
{
    return QStringLiteral("Krellkam");
}

int KrellkamMonitor::tickIntervalMs() const
{
    return qBound(1000,
        QSettings().value(QStringLiteral("plugins/krellkam/interval_ms"), 5000).toInt(),
        300000);
}

QWidget *KrellkamMonitor::createWidget(QWidget *parent)
{
    auto *panel = new Panel(theme(), parent);
    panel->setSurfaceKey(QStringLiteral("panel_bg_krellkam"));

    m_field = new KrellkamField(theme(), panel);
    m_field->setSources(sources());
    panel->addWidget(m_field);
    tick();
    return panel;
}

void KrellkamMonitor::tick()
{
    if (!m_field) return;
    const QList<KrellkamSource> current = sources();
    m_field->setSources(current);
    m_field->refresh();
}

void KrellkamMonitor::shutdown()
{
    if (m_field)
        m_field->stopProcesses();
}

QList<KrellkamSource> KrellkamMonitor::sources() const
{
    return configuredSources();
}

QString KrellkamPlugin::pluginId() const
{
    return QStringLiteral("io.krellix.krellkam");
}

QString KrellkamPlugin::pluginName() const
{
    return QStringLiteral("Krellkam");
}

QString KrellkamPlugin::pluginVersion() const
{
    return QStringLiteral("0.1.0");
}

QList<MonitorBase *> KrellkamPlugin::createMonitors(Theme *theme, QObject *parent)
{
    if (!QSettings().value(QStringLiteral("plugins/krellkam/enabled"), false).toBool())
        return {};
    return {new KrellkamMonitor(theme, parent)};
}
